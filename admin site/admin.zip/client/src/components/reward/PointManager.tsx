import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Coins, Plus, ArrowRightLeft, Gift } from "lucide-react";

const pointSchema = z.object({
  customerId: z.number().min(1, "Customer is required"),
  points: z.number().min(1, "Points must be positive"),
  merchantId: z.number().optional(),
});

const transferSchema = z.object({
  customerId: z.number().min(1, "Customer is required"),
  amount: z.number().min(1, "Amount must be positive"),
});

type PointFormData = z.infer<typeof pointSchema>;
type TransferFormData = z.infer<typeof transferSchema>;

interface PointManagerProps {
  language: string;
  customers: any[];
  merchants: any[];
}

export default function PointManager({ language, customers, merchants }: PointManagerProps) {
  const [addPointsOpen, setAddPointsOpen] = useState(false);
  const [transferOpen, setTransferOpen] = useState(false);
  const [dailyLoginOpen, setDailyLoginOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    register: registerPoints,
    handleSubmit: handlePointsSubmit,
    formState: { errors: pointsErrors },
    reset: resetPoints,
    setValue: setPointsValue,
    watch: watchPoints,
  } = useForm<PointFormData>({
    resolver: zodResolver(pointSchema),
  });

  const {
    register: registerTransfer,
    handleSubmit: handleTransferSubmit,
    formState: { errors: transferErrors },
    reset: resetTransfer,
    setValue: setTransferValue,
    watch: watchTransfer,
  } = useForm<TransferFormData>({
    resolver: zodResolver(transferSchema),
  });

  const addPointsMutation = useMutation({
    mutationFn: (data: PointFormData) => apiRequest("/api/points/add", {
      method: "POST",
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      toast({
        title: language === 'bn' ? "সফল!" : "Success!",
        description: language === 'bn' ? "পয়েন্ট সফলভাবে যোগ করা হয়েছে" : "Points added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      resetPoints();
      setAddPointsOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: language === 'bn' ? "ত্রুটি!" : "Error!",
        description: error.message || (language === 'bn' ? "পয়েন্ট যোগ করতে ব্যর্থ" : "Failed to add points"),
        variant: "destructive",
      });
    },
  });

  const transferMutation = useMutation({
    mutationFn: (data: TransferFormData) => apiRequest("/api/transfer-balance", {
      method: "POST",
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      toast({
        title: language === 'bn' ? "সফল!" : "Success!",
        description: language === 'bn' ? "ব্যালেন্স স্থানান্তরিত হয়েছে" : "Balance transferred successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      resetTransfer();
      setTransferOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: language === 'bn' ? "ত্রুটি!" : "Error!",
        description: error.message || (language === 'bn' ? "স্থানান্তর ব্যর্থ" : "Transfer failed"),
        variant: "destructive",
      });
    },
  });

  const dailyLoginMutation = useMutation({
    mutationFn: (customerId: number) => apiRequest("/api/daily-login", {
      method: "POST",
      body: JSON.stringify({ customerId }),
    }),
    onSuccess: (data) => {
      toast({
        title: language === 'bn' ? "সফল!" : "Success!",
        description: language === 'bn' 
          ? `দৈনিক লগইন রিওয়ার্ড: ${data.reward} পয়েন্ট` 
          : `Daily login reward: ${data.reward} points`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      setDailyLoginOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: language === 'bn' ? "ত্রুটি!" : "Error!",
        description: error.message || (language === 'bn' ? "দৈনিক লগইন প্রক্রিয়া ব্যর্থ" : "Daily login failed"),
        variant: "destructive",
      });
    },
  });

  const onAddPoints = (data: PointFormData) => {
    addPointsMutation.mutate(data);
  };

  const onTransfer = (data: TransferFormData) => {
    transferMutation.mutate(data);
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>
            {language === 'bn' ? 'পয়েন্ট ব্যবস্থাপনা' : 'Point Management'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            <Dialog open={addPointsOpen} onOpenChange={setAddPointsOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  {language === 'bn' ? 'পয়েন্ট যোগ করুন' : 'Add Points'}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {language === 'bn' ? 'পয়েন্ট যোগ করুন' : 'Add Points'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handlePointsSubmit(onAddPoints)} className="space-y-4">
                  <div>
                    <Label>
                      {language === 'bn' ? 'কাস্টমার' : 'Customer'} *
                    </Label>
                    <Select
                      value={watchPoints("customerId")?.toString() || ""}
                      onValueChange={(value) => setPointsValue("customerId", parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={language === 'bn' ? 'নির্বাচন করুন' : 'Select customer'} />
                      </SelectTrigger>
                      <SelectContent>
                        {customers.map((customer) => (
                          <SelectItem key={customer.id} value={customer.id.toString()}>
                            {customer.firstName} {customer.lastName} ({customer.phone})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {pointsErrors.customerId && (
                      <p className="text-sm text-red-600">{pointsErrors.customerId.message}</p>
                    )}
                  </div>

                  <div>
                    <Label>
                      {language === 'bn' ? 'পয়েন্ট' : 'Points'} *
                    </Label>
                    <Input
                      type="number"
                      {...registerPoints("points", { valueAsNumber: true })}
                      placeholder={language === 'bn' ? 'পয়েন্ট সংখ্যা' : 'Number of points'}
                    />
                    {pointsErrors.points && (
                      <p className="text-sm text-red-600">{pointsErrors.points.message}</p>
                    )}
                  </div>

                  <div>
                    <Label>
                      {language === 'bn' ? 'মার্চেন্ট (ঐচ্ছিক)' : 'Merchant (Optional)'}
                    </Label>
                    <Select
                      value={watchPoints("merchantId")?.toString() || ""}
                      onValueChange={(value) => setPointsValue("merchantId", value ? parseInt(value) : undefined)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={language === 'bn' ? 'নির্বাচন করুন' : 'Select merchant'} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">
                          {language === 'bn' ? 'কোনো মার্চেন্ট নেই' : 'No merchant'}
                        </SelectItem>
                        {merchants.map((merchant) => (
                          <SelectItem key={merchant.id} value={merchant.id.toString()}>
                            {merchant.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setAddPointsOpen(false)}>
                      {language === 'bn' ? 'বাতিল' : 'Cancel'}
                    </Button>
                    <Button type="submit" disabled={addPointsMutation.isPending}>
                      {addPointsMutation.isPending
                        ? (language === 'bn' ? 'যোগ করা হচ্ছে...' : 'Adding...')
                        : (language === 'bn' ? 'যোগ করুন' : 'Add Points')
                      }
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>

            <Dialog open={transferOpen} onOpenChange={setTransferOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <ArrowRightLeft className="h-4 w-4 mr-2" />
                  {language === 'bn' ? 'ব্যালেন্স স্থানান্তর' : 'Transfer Balance'}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {language === 'bn' ? 'রিওয়ার্ড থেকে ব্যালেন্সে স্থানান্তর' : 'Transfer from Rewards to Balance'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleTransferSubmit(onTransfer)} className="space-y-4">
                  <div>
                    <Label>
                      {language === 'bn' ? 'কাস্টমার' : 'Customer'} *
                    </Label>
                    <Select
                      value={watchTransfer("customerId")?.toString() || ""}
                      onValueChange={(value) => setTransferValue("customerId", parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={language === 'bn' ? 'নির্বাচন করুন' : 'Select customer'} />
                      </SelectTrigger>
                      <SelectContent>
                        {customers.map((customer) => (
                          <SelectItem key={customer.id} value={customer.id.toString()}>
                            {customer.firstName} {customer.lastName} ({customer.phone})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>
                      {language === 'bn' ? 'পরিমাণ' : 'Amount'} *
                    </Label>
                    <Input
                      type="number"
                      {...registerTransfer("amount", { valueAsNumber: true })}
                      placeholder={language === 'bn' ? 'স্থানান্তরের পরিমাণ' : 'Amount to transfer'}
                    />
                    <p className="text-sm text-gray-600 mt-1">
                      {language === 'bn' 
                        ? '১২.৫% ভ্যাট ও সার্ভিস চার্জ কাটা হবে' 
                        : '12.5% VAT & service charge will be deducted'
                      }
                    </p>
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setTransferOpen(false)}>
                      {language === 'bn' ? 'বাতিল' : 'Cancel'}
                    </Button>
                    <Button type="submit" disabled={transferMutation.isPending}>
                      {transferMutation.isPending
                        ? (language === 'bn' ? 'স্থানান্তর হচ্ছে...' : 'Transferring...')
                        : (language === 'bn' ? 'স্থানান্তর করুন' : 'Transfer')
                      }
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>

            <Dialog open={dailyLoginOpen} onOpenChange={setDailyLoginOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Gift className="h-4 w-4 mr-2" />
                  {language === 'bn' ? 'দৈনিক লগইন রিওয়ার্ড' : 'Daily Login Reward'}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {language === 'bn' ? 'দৈনিক লগইন রিওয়ার্ড প্রদান' : 'Process Daily Login Reward'}
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <p className="text-sm text-gray-600">
                    {language === 'bn' 
                      ? 'কাস্টমারকে ১০০-২০০ পয়েন্ট দৈনিক লগইন রিওয়ার্ড দিন' 
                      : 'Give customer 100-200 points daily login reward'
                    }
                  </p>
                  
                  <Select
                    onValueChange={(value) => {
                      const customerId = parseInt(value);
                      dailyLoginMutation.mutate(customerId);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={language === 'bn' ? 'কাস্টমার নির্বাচন করুন' : 'Select customer'} />
                    </SelectTrigger>
                    <SelectContent>
                      {customers.map((customer) => (
                        <SelectItem key={customer.id} value={customer.id.toString()}>
                          {customer.firstName} {customer.lastName} ({customer.phone})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-4">
              {language === 'bn' ? 'রিওয়ার্ড সিস্টেম তথ্য' : 'Reward System Information'}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 border rounded-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">1500</div>
                  <div className="text-sm text-gray-600">
                    {language === 'bn' ? 'পয়েন্ট → রিওয়ার্ড নম্বর' : 'Points → Reward Number'}
                  </div>
                </div>
              </div>
              
              <div className="p-4 border rounded-lg">
                <div className="text-center">
                  <div className="text-lg font-semibold">
                    {language === 'bn' ? 'চার স্তরের রিওয়ার্ড' : 'Four-Tier Rewards'}
                  </div>
                  <div className="text-sm space-y-1">
                    <div>6 → 800 {language === 'bn' ? 'পয়েন্ট' : 'points'}</div>
                    <div>30 → 1500 {language === 'bn' ? 'পয়েন্ট' : 'points'}</div>
                    <div>120 → 3500 {language === 'bn' ? 'পয়েন্ট' : 'points'}</div>
                    <div>480 → 32200 {language === 'bn' ? 'পয়েন্ট' : 'points'}</div>
                  </div>
                </div>
              </div>
              
              <div className="p-4 border rounded-lg">
                <div className="text-center">
                  <div className="text-lg font-semibold">
                    {language === 'bn' ? 'অ্যাফিলিয়েট কমিশন' : 'Affiliate Commission'}
                  </div>
                  <div className="text-sm">
                    <Badge variant="secondary">5%</Badge>
                    <div className="mt-1 text-gray-600">
                      {language === 'bn' ? 'রেফার করা কাস্টমারের পয়েন্টের' : 'of referred customer points'}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-4 border rounded-lg">
                <div className="text-center">
                  <div className="text-lg font-semibold">
                    {language === 'bn' ? 'ভ্যাট ও সার্ভিস চার্জ' : 'VAT & Service Charge'}
                  </div>
                  <div className="text-sm">
                    <Badge variant="outline">12.5%</Badge>
                    <div className="mt-1 text-gray-600">
                      {language === 'bn' ? 'ব্যালেন্স স্থানান্তরে' : 'on balance transfers'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}