import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { UserPlus } from "lucide-react";

const customerSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  phone: z.string().min(1, "Phone is required"),
  dateOfBirth: z.string().optional(),
  bloodGroup: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  district: z.string().optional(),
  postcode: z.string().optional(),
  countryId: z.number().min(1, "Country is required"),
});

type CustomerFormData = z.infer<typeof customerSchema>;

interface AddCustomerFormProps {
  language: string;
  selectedCountry: string;
}

export default function AddCustomerForm({ language, selectedCountry }: AddCustomerFormProps) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: countries } = useQuery({
    queryKey: ['/api/countries'],
    enabled: open,
    retry: false,
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<CustomerFormData>({
    resolver: zodResolver(customerSchema),
    defaultValues: {
      countryId: selectedCountry === "global" ? 1 : parseInt(selectedCountry),
    },
  });

  const createCustomerMutation = useMutation({
    mutationFn: (data: CustomerFormData) => {
      // Clean up data and keep date as string for server processing
      const formData = {
        ...data,
        email: data.email || undefined, // Convert empty string to undefined
        bloodGroup: data.bloodGroup || undefined,
        address: data.address || undefined,
        city: data.city || undefined,
        district: data.district || undefined,
        postcode: data.postcode || undefined,
      };
      return apiRequest("POST", "/api/customers", formData);
    },
    onSuccess: () => {
      toast({
        title: language === 'bn' ? "সফল!" : "Success!",
        description: language === 'bn' ? "কাস্টমার সফলভাবে যোগ করা হয়েছে" : "Customer added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      reset();
      setOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: language === 'bn' ? "ত্রুটি!" : "Error!",
        description: error.message || (language === 'bn' ? "কাস্টমার যোগ করতে ব্যর্থ" : "Failed to add customer"),
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CustomerFormData) => {
    createCustomerMutation.mutate(data);
  };

  const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <UserPlus className="h-4 w-4 mr-2" />
          {language === 'bn' ? 'কাস্টমার যোগ করুন' : 'Add Customer'}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {language === 'bn' ? 'নতুন কাস্টমার যোগ করুন' : 'Add New Customer'}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="firstName">
                {language === 'bn' ? 'প্রথম নাম' : 'First Name'} *
              </Label>
              <Input
                id="firstName"
                {...register("firstName")}
                placeholder={language === 'bn' ? 'প্রথম নাম' : 'First name'}
              />
              {errors.firstName && (
                <p className="text-sm text-red-600">{errors.firstName.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="lastName">
                {language === 'bn' ? 'শেষ নাম' : 'Last Name'} *
              </Label>
              <Input
                id="lastName"
                {...register("lastName")}
                placeholder={language === 'bn' ? 'শেষ নাম' : 'Last name'}
              />
              {errors.lastName && (
                <p className="text-sm text-red-600">{errors.lastName.message}</p>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="phone">
              {language === 'bn' ? 'ফোন' : 'Phone'} *
            </Label>
            <Input
              id="phone"
              {...register("phone")}
              placeholder={language === 'bn' ? 'ফোন নম্বর' : 'Phone number'}
            />
            {errors.phone && (
              <p className="text-sm text-red-600">{errors.phone.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="email">
              {language === 'bn' ? 'ইমেইল' : 'Email'}
            </Label>
            <Input
              id="email"
              type="email"
              {...register("email")}
              placeholder={language === 'bn' ? 'ইমেইল ঠিকানা' : 'Email address'}
            />
            {errors.email && (
              <p className="text-sm text-red-600">{errors.email.message}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="dateOfBirth">
                {language === 'bn' ? 'জন্ম তারিখ' : 'Date of Birth'}
              </Label>
              <Input
                id="dateOfBirth"
                type="date"
                {...register("dateOfBirth")}
              />
            </div>

            <div>
              <Label htmlFor="bloodGroup">
                {language === 'bn' ? 'রক্তের গ্রুপ' : 'Blood Group'}
              </Label>
              <Select
                value={watch("bloodGroup") || ""}
                onValueChange={(value) => setValue("bloodGroup", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder={language === 'bn' ? 'নির্বাচন করুন' : 'Select'} />
                </SelectTrigger>
                <SelectContent>
                  {bloodGroups.map((group) => (
                    <SelectItem key={group} value={group}>
                      {group}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="address">
              {language === 'bn' ? 'ঠিকানা' : 'Address'}
            </Label>
            <Textarea
              id="address"
              {...register("address")}
              placeholder={language === 'bn' ? 'বাড়ির ঠিকানা' : 'Home address'}
              rows={2}
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="city">
                {language === 'bn' ? 'শহর' : 'City'}
              </Label>
              <Input
                id="city"
                {...register("city")}
                placeholder={language === 'bn' ? 'শহর' : 'City'}
              />
            </div>

            <div>
              <Label htmlFor="district">
                {language === 'bn' ? 'জেলা' : 'District'}
              </Label>
              <Input
                id="district"
                {...register("district")}
                placeholder={language === 'bn' ? 'জেলা' : 'District'}
              />
            </div>

            <div>
              <Label htmlFor="postcode">
                {language === 'bn' ? 'পোস্ট কোড' : 'Post Code'}
              </Label>
              <Input
                id="postcode"
                {...register("postcode")}
                placeholder={language === 'bn' ? 'পোস্ট কোড' : 'Post code'}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="countryId">
              {language === 'bn' ? 'দেশ' : 'Country'} *
            </Label>
            <Select
              value={watch("countryId")?.toString() || ""}
              onValueChange={(value) => setValue("countryId", parseInt(value))}
            >
              <SelectTrigger>
                <SelectValue placeholder={language === 'bn' ? 'দেশ নির্বাচন করুন' : 'Select country'} />
              </SelectTrigger>
              <SelectContent>
                {countries && countries.length > 0 ? (
                  countries.map((country: any) => (
                    <SelectItem key={country.id} value={country.id.toString()}>
                      <div className="flex items-center space-x-2">
                        <span>{country.flag}</span>
                        <span>{country.name}</span>
                      </div>
                    </SelectItem>
                  ))
                ) : (
                  <>
                    <SelectItem value="1">
                      <div className="flex items-center space-x-2">
                        <span>🇧🇩</span>
                        <span>Bangladesh</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="2">
                      <div className="flex items-center space-x-2">
                        <span>🇲🇾</span>
                        <span>Malaysia</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="3">
                      <div className="flex items-center space-x-2">
                        <span>🇦🇪</span>
                        <span>UAE</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="4">
                      <div className="flex items-center space-x-2">
                        <span>🇵🇭</span>
                        <span>Philippines</span>
                      </div>
                    </SelectItem>
                  </>
                )}
              </SelectContent>
            </Select>
            {errors.countryId && (
              <p className="text-sm text-red-600">{errors.countryId.message}</p>
            )}
          </div>

          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </Button>
            <Button
              type="submit"
              disabled={createCustomerMutation.isPending}
            >
              {createCustomerMutation.isPending
                ? (language === 'bn' ? 'যোগ করা হচ্ছে...' : 'Adding...')
                : (language === 'bn' ? 'যোগ করুন' : 'Add Customer')
              }
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}