import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus } from "lucide-react";

const merchantSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  phone: z.string().min(1, "Phone is required"),
  address: z.string().optional(),
  businessType: z.enum(["merchant", "e_merchant"]),
  tier: z.enum(["regular", "star", "double_star", "triple_star", "executive", "senior_executive", "manager", "co_founder"]),
  countryId: z.number().min(1, "Country is required"),
});

type MerchantFormData = z.infer<typeof merchantSchema>;

interface AddMerchantFormProps {
  language: string;
  selectedCountry: string;
}

export default function AddMerchantForm({ language, selectedCountry }: AddMerchantFormProps) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
  } = useForm<MerchantFormData>({
    resolver: zodResolver(merchantSchema),
    defaultValues: {
      businessType: "merchant",
      tier: "regular",
      countryId: selectedCountry === "global" ? 1 : parseInt(selectedCountry),
    },
  });

  const createMerchantMutation = useMutation({
    mutationFn: (data: MerchantFormData) => apiRequest("/api/merchants", {
      method: "POST",
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      toast({
        title: language === 'bn' ? "সফল!" : "Success!",
        description: language === 'bn' ? "মার্চেন্ট সফলভাবে যোগ করা হয়েছে" : "Merchant added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/merchants'] });
      reset();
      setOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: language === 'bn' ? "ত্রুটি!" : "Error!",
        description: error.message || (language === 'bn' ? "মার্চেন্ট যোগ করতে ব্যর্থ" : "Failed to add merchant"),
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: MerchantFormData) => {
    createMerchantMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          {language === 'bn' ? 'মার্চেন্ট যোগ করুন' : 'Add Merchant'}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {language === 'bn' ? 'নতুন মার্চেন্ট যোগ করুন' : 'Add New Merchant'}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="name">
              {language === 'bn' ? 'নাম' : 'Name'} *
            </Label>
            <Input
              id="name"
              {...register("name")}
              placeholder={language === 'bn' ? 'মার্চেন্টের নাম' : 'Merchant name'}
            />
            {errors.name && (
              <p className="text-sm text-red-600">{errors.name.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="email">
              {language === 'bn' ? 'ইমেইল' : 'Email'}
            </Label>
            <Input
              id="email"
              type="email"
              {...register("email")}
              placeholder={language === 'bn' ? 'ইমেইল ঠিকানা' : 'Email address'}
            />
            {errors.email && (
              <p className="text-sm text-red-600">{errors.email.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="phone">
              {language === 'bn' ? 'ফোন' : 'Phone'} *
            </Label>
            <Input
              id="phone"
              {...register("phone")}
              placeholder={language === 'bn' ? 'ফোন নম্বর' : 'Phone number'}
            />
            {errors.phone && (
              <p className="text-sm text-red-600">{errors.phone.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="businessType">
              {language === 'bn' ? 'ব্যবসার ধরন' : 'Business Type'}
            </Label>
            <Select
              value={watch("businessType")}
              onValueChange={(value: "merchant" | "e_merchant") => setValue("businessType", value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="merchant">
                  {language === 'bn' ? 'মার্চেন্ট' : 'Merchant'}
                </SelectItem>
                <SelectItem value="e_merchant">
                  {language === 'bn' ? 'ই-মার্চেন্ট' : 'E-Merchant'}
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="tier">
              {language === 'bn' ? 'স্তর' : 'Tier'}
            </Label>
            <Select
              value={watch("tier")}
              onValueChange={(value: any) => setValue("tier", value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="regular">
                  {language === 'bn' ? 'সাধারণ' : 'Regular'}
                </SelectItem>
                <SelectItem value="star">
                  {language === 'bn' ? 'স্টার' : 'Star'}
                </SelectItem>
                <SelectItem value="double_star">
                  {language === 'bn' ? 'ডাবল স্টার' : 'Double Star'}
                </SelectItem>
                <SelectItem value="triple_star">
                  {language === 'bn' ? 'ট্রিপল স্টার' : 'Triple Star'}
                </SelectItem>
                <SelectItem value="executive">
                  {language === 'bn' ? 'এক্সিকিউটিভ' : 'Executive'}
                </SelectItem>
                <SelectItem value="senior_executive">
                  {language === 'bn' ? 'সিনিয়র এক্সিকিউটিভ' : 'Senior Executive'}
                </SelectItem>
                <SelectItem value="manager">
                  {language === 'bn' ? 'ম্যানেজার' : 'Manager'}
                </SelectItem>
                <SelectItem value="co_founder">
                  {language === 'bn' ? 'কো-ফাউন্ডার' : 'Co-Founder'}
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="address">
              {language === 'bn' ? 'ঠিকানা' : 'Address'}
            </Label>
            <Textarea
              id="address"
              {...register("address")}
              placeholder={language === 'bn' ? 'ব্যবসার ঠিকানা' : 'Business address'}
              rows={3}
            />
          </div>

          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </Button>
            <Button
              type="submit"
              disabled={createMerchantMutation.isPending}
            >
              {createMerchantMutation.isPending
                ? (language === 'bn' ? 'যোগ করা হচ্ছে...' : 'Adding...')
                : (language === 'bn' ? 'যোগ করুন' : 'Add Merchant')
              }
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}