import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useTranslation } from "@/lib/i18n";

interface MerchantTiersProps {
  data: any;
  language: string;
}

export default function MerchantTiers({ data, language }: MerchantTiersProps) {
  const { t } = useTranslation(language as any);

  const tierConfig = [
    {
      key: "executive",
      name: "Executive",
      nameBengali: "এক্সিকিউটিভ",
      description: "Highest tier",
      descriptionBengali: "সর্বোচ্চ স্তর",
      gradient: "from-purple-50 to-purple-100",
      border: "border-purple-200",
      textColor: "text-purple-700",
      bgColor: "bg-purple-500",
      emoji: "👑",
    },
    {
      key: "triple_star",
      name: "Triple Star ⭐⭐⭐",
      nameBengali: "ট্রিপল স্টার ⭐⭐⭐",
      description: "Premium tier",
      descriptionBengali: "প্রিমিয়াম স্তর",
      gradient: "from-yellow-50 to-yellow-100",
      border: "border-yellow-200",
      textColor: "text-yellow-700",
      bgColor: "bg-yellow-500",
      emoji: "💎",
    },
    {
      key: "double_star",
      name: "Double Star ⭐⭐",
      nameBengali: "ডাবল স্টার ⭐⭐",
      description: "Advanced tier",
      descriptionBengali: "উন্নত স্তর",
      gradient: "from-blue-50 to-blue-100",
      border: "border-blue-200",
      textColor: "text-blue-700",
      bgColor: "bg-blue-500",
      emoji: "🏆",
    },
    {
      key: "star",
      name: "Star Merchant ⭐",
      nameBengali: "স্টার মার্চেন্ট ⭐",
      description: "Standard tier",
      descriptionBengali: "মানক স্তর",
      gradient: "from-green-50 to-green-100",
      border: "border-green-200",
      textColor: "text-green-700",
      bgColor: "bg-green-500",
      emoji: "🌟",
    },
    {
      key: "regular",
      name: "Regular",
      nameBengali: "নিয়মিত",
      description: "Basic tier",
      descriptionBengali: "মৌলিক স্তর",
      gradient: "from-gray-50 to-gray-100",
      border: "border-gray-200",
      textColor: "text-gray-700",
      bgColor: "bg-gray-500",
      emoji: "🥉",
    },
  ];

  return (
    <Card className="border-gray-100">
      <CardHeader className="border-b border-gray-100">
        <CardTitle className="text-lg font-semibold text-gray-900">
          {t("dashboard.merchantTiers")}
        </CardTitle>
        {language === 'bn' && (
          <p className="text-sm text-gray-500 font-bengali">মার্চেন্ট স্তর</p>
        )}
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {tierConfig.map((tier) => (
            <div
              key={tier.key}
              className={`flex items-center justify-between p-3 rounded-lg bg-gradient-to-r ${tier.gradient} border ${tier.border}`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 ${tier.bgColor} rounded-full`}></div>
                <div>
                  <p className="font-medium text-gray-900">
                    {language === 'bn' ? tier.nameBengali : tier.name}
                  </p>
                  <p className="text-sm text-gray-500">
                    {language === 'bn' ? tier.descriptionBengali : tier.description}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-xl">{tier.emoji}</span>
                <span className={`font-bold ${tier.textColor}`}>
                  {data?.byTier?.[tier.key] || 0}
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
