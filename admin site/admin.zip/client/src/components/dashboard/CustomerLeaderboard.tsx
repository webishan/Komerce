import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useTranslation } from "@/lib/i18n";

interface CustomerLeaderboardProps {
  title: string;
  titleBengali: string;
  data: any[];
  language: string;
  valueKey: 'serialNumbers' | 'referralCount';
  colorScheme: 'blue' | 'purple';
}

export default function CustomerLeaderboard({
  title,
  titleBengali,
  data,
  language,
  valueKey,
  colorScheme,
}: CustomerLeaderboardProps) {
  const { t } = useTranslation(language as any);

  const colorMap = {
    blue: {
      1: "from-primary to-primary-600",
      2: "from-green-400 to-green-600",  
      3: "from-amber-400 to-amber-600",
      text: {
        1: "text-primary",
        2: "text-green-600",
        3: "text-amber-600",
      }
    },
    purple: {
      1: "from-purple-400 to-purple-600",
      2: "from-indigo-400 to-indigo-600",
      3: "from-pink-400 to-pink-600", 
      text: {
        1: "text-purple-600",
        2: "text-indigo-600", 
        3: "text-pink-600",
      }
    }
  };

  const colors = colorMap[colorScheme];

  return (
    <Card className="border-gray-100">
      <CardHeader className="border-b border-gray-100">
        <CardTitle className="text-lg font-semibold text-gray-900">
          {title}
        </CardTitle>
        {language === 'bn' && (
          <p className="text-sm text-gray-500 font-bengali">{titleBengali}</p>
        )}
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-3">
          {data.slice(0, 3).map((customer, index) => {
            const position = index + 1;
            const gradientClass = colors[position as keyof typeof colors] as string;
            const textColorClass = colors.text[position as keyof typeof colors.text];
            
            return (
              <div key={customer.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 bg-gradient-to-br ${gradientClass} rounded-full flex items-center justify-center text-white text-sm font-bold`}>
                    {position}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">
                      {customer.firstName} {customer.lastName}
                    </p>
                    <p className="text-sm text-gray-500">
                      {customer.city}, {customer.country?.code?.toUpperCase()}
                    </p>
                  </div>
                </div>
                <span className={`font-bold ${textColorClass}`}>
                  {customer[valueKey] || 0}
                </span>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
