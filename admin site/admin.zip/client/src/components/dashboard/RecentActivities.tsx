import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useTranslation } from "@/lib/i18n";

interface Activity {
  id: string;
  description: string;
  descriptionBengali: string;
  time: string;
  timeBengali: string;
  type: 'success' | 'info' | 'warning';
}

interface RecentActivitiesProps {
  data: Activity[];
  language: string;
}

export default function RecentActivities({ data, language }: RecentActivitiesProps) {
  const { t } = useTranslation(language as any);

  const typeColors = {
    success: "bg-green-500",
    info: "bg-blue-500", 
    warning: "bg-yellow-500",
  };

  return (
    <Card className="border-gray-100">
      <CardHeader className="border-b border-gray-100">
        <CardTitle className="text-lg font-semibold text-gray-900">
          {t("dashboard.recentActivities")}
        </CardTitle>
        {language === 'bn' && (
          <p className="text-sm text-gray-500 font-bengali">সাম্প্রতিক কার্যক্রম</p>
        )}
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {data.length === 0 ? (
            <p className="text-gray-500 text-center py-4">
              {language === 'bn' ? 'কোন সাম্প্রতিক কার্যক্রম নেই' : 'No recent activities'}
            </p>
          ) : (
            data.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-3">
                <div className={`w-2 h-2 ${typeColors[activity.type]} rounded-full mt-2 flex-shrink-0`}></div>
                <div className="flex-1">
                  <p className="text-sm text-gray-900">
                    {language === 'bn' ? activity.descriptionBengali : activity.description}
                  </p>
                  <p className="text-xs text-gray-500 font-bengali">
                    {language === 'bn' ? activity.timeBengali : activity.time}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
