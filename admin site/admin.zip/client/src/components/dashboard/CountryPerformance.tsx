import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useTranslation } from "@/lib/i18n";

interface CountryPerformanceProps {
  data: any[];
  language: string;
}

export default function CountryPerformance({ data, language }: CountryPerformanceProps) {
  const { t } = useTranslation(language as any);

  const countryFlags: Record<string, string> = {
    bangladesh: "🇧🇩",
    malaysia: "🇲🇾",
    uae: "🇦🇪",
    philippines: "🇵🇭",
  };

  const countryNames: Record<string, { en: string; bn: string }> = {
    bangladesh: { en: "Bangladesh", bn: "বাংলাদেশ" },
    malaysia: { en: "Malaysia", bn: "মালয়েশিয়া" },
    uae: { en: "UAE", bn: "সংযুক্ত আরব আমিরাত" },
    philippines: { en: "Philippines", bn: "ফিলিপাইন্স" },
  };

  return (
    <Card className="border-gray-100">
      <CardHeader className="border-b border-gray-100">
        <CardTitle className="text-lg font-semibold text-gray-900">
          {t("dashboard.countryPerformance")}
        </CardTitle>
        {language === 'bn' && (
          <p className="text-sm text-gray-500 font-bengali">দেশভিত্তিক কর্মক্ষমতা</p>
        )}
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {data.map((country, index) => {
            const countryCode = country.country?.code?.toLowerCase();
            const flag = countryFlags[countryCode] || "🏳️";
            const countryName = countryNames[countryCode];
            
            return (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-lg">{flag}</span>
                  <div>
                    <p className="font-medium text-gray-900">
                      {countryName ? 
                        (language === 'bn' ? countryName.bn : countryName.en) : 
                        country.country?.name || 'Unknown'
                      }
                    </p>
                    <p className="text-sm text-gray-500">
                      {country.customerCount?.toLocaleString()} customers
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">
                    ${Number(country.totalBalance || 0).toLocaleString()}
                  </p>
                  <p className="text-sm text-green-600">
                    {country.totalPoints?.toLocaleString()} pts
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
