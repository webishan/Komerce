import { useState } from "react";
import Sidebar from "./Sidebar";
import TopHeader from "./TopHeader";
import { useAuth } from "@/hooks/useAuth";

interface AdminLayoutProps {
  children: React.ReactNode;
  language: string;
  onLanguageChange: (language: string) => void;
  selectedCountry: string;
  onCountryChange: (country: string) => void;
}

export default function AdminLayout({
  children,
  language,
  onLanguageChange,
  selectedCountry,
  onCountryChange,
}: AdminLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user } = useAuth();

  return (
    <div className="min-h-screen flex bg-gray-50">
      <Sidebar
        language={language}
        selectedCountry={selectedCountry}
        onCountryChange={onCountryChange}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      
      <div className="flex-1 flex flex-col lg:ml-64">
        <TopHeader
          language={language}
          onLanguageChange={onLanguageChange}
          onMenuClick={() => setSidebarOpen(true)}
          user={user}
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
