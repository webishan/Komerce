import { Bell, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import LanguageSwitcher from "@/components/common/LanguageSwitcher";
import { useTranslation } from "@/lib/i18n";

interface TopHeaderProps {
  language: string;
  onLanguageChange: (language: string) => void;
  onMenuClick: () => void;
  user?: any;
}

export default function TopHeader({ 
  language, 
  onLanguageChange, 
  onMenuClick,
  user 
}: TopHeaderProps) {
  const { t } = useTranslation(language as any);

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 h-16 flex items-center justify-between px-6">
      <div className="flex items-center space-x-4">
        <Button
          variant="ghost"
          size="sm"
          className="lg:hidden"
          onClick={onMenuClick}
        >
          <Menu className="w-6 h-6" />
        </Button>
        <div>
          <h1 className="text-xl font-semibold text-gray-800">
            {t("dashboard.title")}
          </h1>
          <p className="text-sm text-gray-500">
            {t("dashboard.subtitle")}
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        {/* Language Switcher */}
        <LanguageSwitcher 
          language={language} 
          onLanguageChange={onLanguageChange} 
        />

        {/* Notifications */}
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="w-5 h-5" />
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </Button>

        {/* User Profile */}
        <div className="flex items-center space-x-3">
          <Avatar className="w-8 h-8">
            <AvatarImage src={user?.profileImageUrl} />
            <AvatarFallback>
              {user?.firstName?.[0]}{user?.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          <div className="hidden md:block">
            <p className="text-sm font-medium text-gray-700">
              {user?.firstName} {user?.lastName}
            </p>
            <p className="text-xs text-gray-500">
              {user?.role === 'super_admin' ? 'Super Admin' : 'Admin'}
            </p>
          </div>
        </div>

        {/* Logout */}
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => window.location.href = '/api/logout'}
        >
          {language === 'bn' ? 'লগআউট' : 'Logout'}
        </Button>
      </div>
    </header>
  );
}
