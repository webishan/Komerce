import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useTranslation } from "@/lib/i18n";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  LayoutDashboard,
  Store,
  Users,
  TrendingUp,
  Settings as SettingsIcon,
  UserCheck,
  Headphones,
  Building2,
  X,
  ChevronDown,
} from "lucide-react";

interface SidebarProps {
  language: string;
  selectedCountry: string;
  onCountryChange: (country: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ 
  language, 
  selectedCountry, 
  onCountryChange, 
  isOpen, 
  onClose 
}: SidebarProps) {
  const [location] = useLocation();
  const { t } = useTranslation(language as any);

  const navigation = [
    {
      name: t("common.dashboard"),
      nameBengali: "ড্যাশবোর্ড",
      href: "/",
      icon: LayoutDashboard,
      current: location === "/",
    },
    {
      name: t("common.merchants"),
      nameBengali: "মার্চেন্ট",
      href: "/merchants",
      icon: Store,
      current: location.startsWith("/merchants"),
      subItems: [
        { name: "All Merchants", href: "/merchants" },
        { name: "E-Merchants", href: "/merchants/e-merchants" },
        { name: "Star Merchants", href: "/merchants/star" },
        { name: "Executive Merchants", href: "/merchants/executive" },
      ],
    },
    {
      name: t("common.customers"),
      nameBengali: "গ্রাহক",
      href: "/customers",
      icon: Users,
      current: location.startsWith("/customers"),
    },
    {
      name: t("common.analytics"),
      nameBengali: "বিশ্লেষণ",
      href: "/analytics",
      icon: TrendingUp,
      current: location.startsWith("/analytics"),
    },
    {
      name: t("common.settings"),
      nameBengali: "সেটিংস",
      href: "/settings",
      icon: SettingsIcon,
      current: location.startsWith("/settings"),
    },
  ];

  const managementItems = [
    {
      name: "Co-Founders",
      nameBengali: "সহ-প্রতিষ্ঠাতা",
      href: "/co-founders",
      icon: UserCheck,
      current: location.startsWith("/co-founders"),
    },
    {
      name: "Staff Management",
      nameBengali: "কর্মী ব্যবস্থাপনা",
      href: "/staff",
      icon: Building2,
      current: location.startsWith("/staff"),
    },
    {
      name: "Customer Care",
      nameBengali: "গ্রাহক সেবা",
      href: "/customer-care",
      icon: Headphones,
      current: location.startsWith("/customer-care"),
    },
  ];

  const countryOptions = [
    { value: "global", label: "🌍 Global Admin", labelBengali: "🌍 গ্লোবাল অ্যাডমিন" },
    { value: "bangladesh", label: "🇧🇩 Bangladesh Admin", labelBengali: "🇧🇩 বাংলাদেশ অ্যাডমিন" },
    { value: "malaysia", label: "🇲🇾 Malaysia Admin", labelBengali: "🇲🇾 মালয়েশিয়া অ্যাডমিন" },
    { value: "uae", label: "🇦🇪 UAE Admin", labelBengali: "🇦🇪 সংযুক্ত আরব আমিরাত অ্যাডমিন" },
    { value: "philippines", label: "🇵🇭 Philippines Admin", labelBengali: "🇵🇭 ফিলিপাইন্স অ্যাডমিন" },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden" 
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside className={cn(
        "w-64 bg-white shadow-lg fixed h-full z-30 transform transition-transform duration-200 ease-in-out",
        isOpen ? "translate-x-0" : "-translate-x-full",
        "lg:translate-x-0"
      )}>
        {/* Header */}
        <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-green-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">K</span>
            </div>
            <span className="font-bold text-xl text-gray-800">KOMARCE</span>
          </div>
          <button className="lg:hidden" onClick={onClose}>
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Country Selection */}
        <div className="p-4 border-b border-gray-200">
          <div className="space-y-2">
            <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">
              {language === 'bn' ? 'প্রশাসনের ধরন' : 'Admin Type'}
            </label>
            <Select value={selectedCountry} onValueChange={onCountryChange}>
              <SelectTrigger className="w-full bg-gray-50 border-gray-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {countryOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {language === 'bn' ? option.labelBengali : option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Main Navigation */}
        <nav className="mt-6 px-4">
          <div className="space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.name}>
                  <Link href={item.href}>
                    <a className={cn(
                      "flex items-center px-4 py-3 rounded-lg font-medium transition-colors",
                      item.current
                        ? "text-primary bg-primary/10"
                        : "text-gray-600 hover:bg-gray-100"
                    )}>
                      <Icon className="w-5 h-5 mr-3" />
                      <span className="flex-1">
                        {item.name}
                        {language === 'bn' && item.nameBengali && (
                          <span className="text-sm text-gray-500 block">
                            {item.nameBengali}
                          </span>
                        )}
                      </span>
                    </a>
                  </Link>
                  
                  {/* Sub-items for merchants */}
                  {item.subItems && item.current && (
                    <div className="ml-12 mt-2 space-y-1">
                      {item.subItems.map((subItem) => (
                        <Link key={subItem.href} href={subItem.href}>
                          <a className="block px-3 py-2 text-sm text-gray-600 hover:text-primary rounded">
                            {subItem.name}
                          </a>
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </nav>

        {/* Management Section */}
        <div className="mt-8 px-4">
          <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-3">
            {language === 'bn' ? 'ব্যবস্থাপনা' : 'Management'}
          </h3>
          <div className="space-y-2">
            {managementItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.name} href={item.href}>
                  <a className={cn(
                    "flex items-center px-4 py-2 rounded-lg text-sm transition-colors",
                    item.current
                      ? "text-primary bg-primary/10"
                      : "text-gray-600 hover:bg-gray-100"
                  )}>
                    <Icon className="w-4 h-4 mr-3" />
                    {item.name}
                    {language === 'bn' && (
                      <span className="text-xs text-gray-500 ml-2">
                        {item.nameBengali}
                      </span>
                    )}
                  </a>
                </Link>
              );
            })}
          </div>
        </div>
      </aside>
    </>
  );
}
