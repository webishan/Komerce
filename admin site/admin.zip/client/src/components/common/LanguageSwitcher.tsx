import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface LanguageSwitcherProps {
  language: string;
  onLanguageChange: (language: string) => void;
}

export default function LanguageSwitcher({ language, onLanguageChange }: LanguageSwitcherProps) {
  return (
    <Select value={language} onValueChange={onLanguageChange}>
      <SelectTrigger className="w-32 bg-gray-50 border-gray-200">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="en">🇺🇸 English</SelectItem>
        <SelectItem value="bn">🇧🇩 বাংলা</SelectItem>
      </SelectContent>
    </Select>
  );
}
